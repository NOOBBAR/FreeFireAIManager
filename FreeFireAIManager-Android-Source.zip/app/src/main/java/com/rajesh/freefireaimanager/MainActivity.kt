package com.rajesh.freefireaimanager

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(15, 17, 25)
    private val panel = Color.rgb(29, 33, 46)
    private val accent = Color.rgb(255, 164, 35)
    private val white = Color.WHITE
    private val muted = Color.rgb(190, 195, 208)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 28)
            setBackgroundColor(bg)
        }
        scroll.addView(root)
        root.addView(text("FREE FIRE", 14, accent, true))
        root.addView(text("AI MANAGER", 30, white, true))
        root.addView(text("Un YouTube channel-oda AI control room 🎮", 15, muted, false))
        root.addView(space(22))
        val status = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            setBackgroundColor(panel)
        }
        status.addView(text("YOUR CONTENT PLAN", 13, accent, true))
        status.addView(text("Daily: 2 Shorts\nWeekly: 3 long videos", 18, white, true))
        status.addView(text("First version • Free tools-first setup", 12, muted, false))
        root.addView(status, matchWrap())
        root.addView(space(18))
        root.addView(text("AI TOOLS", 16, white, true))
        addAction(root, "💡  Free Fire video ideas", "Topic ideas and content planning")
        addAction(root, "✍️  Script writer", "Create Tamil/Tanglish scripts")
        addAction(root, "🎙️  AI voice-over", "Prepare narration workflow")
        addAction(root, "🎬  Shorts & long videos", "Plan video assembly from your footage")
        addAction(root, "🖼️  Thumbnail planner", "Create thumbnail concepts and text")
        addAction(root, "📤  YouTube upload", "Upload/scheduling integration is not connected yet")
        addAction(root, "📊  Channel analytics", "Connect your YouTube channel in a later setup step")
        root.addView(space(18))
        root.addView(text("NOTE: This is the starter dashboard. AI generation and YouTube upload need service/API setup; they are not active in this prototype yet.", 12, muted, false))
        setContentView(scroll)
    }

    private fun addAction(root: LinearLayout, title: String, detail: String) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 15, 16, 15)
            setBackgroundColor(panel)
        }
        card.addView(text(title, 17, white, true))
        card.addView(text(detail, 12, muted, false))
        card.setOnClickListener {
            Toast.makeText(this, "$title — next setup step", Toast.LENGTH_SHORT).show()
        }
        val params = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        params.topMargin = 10
        root.addView(card, params)
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(0, 3, 0, 3)
        }

    private fun space(height: Int) = android.view.View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, height)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )
}
