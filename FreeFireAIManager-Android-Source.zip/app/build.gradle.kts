plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.rajesh.freefireaimanager"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.rajesh.freefireaimanager"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "0.1"
    }
}
